﻿<?php
// no direct access
defined('_JEXEC') or die;
$needle = 'index.php?option=com_ma_easypayzarinpal&view=pay';
$menu = JFactory::getApplication()->getMenu();
$item = $menu->getItems('link', $needle, true);
$cntlink = !empty($item) ? $needle .'&amp;Itemid=' . $item->id : $needle ;
?>
<style>
#ma-easypayzarinpal-product table{width:100%;padding:5px;}
#ma-easypayzarinpal-product table input#cost{border:none;}
#ma-easypayzarinpal-product table span{display: block;margin: 5px auto;text-align: center;width: 100% !important;}
#ma-easypayzarinpal-product table input#submit{display: table;margin: 5px auto;text-align: center;width: 60%;}
</style>
<div id="ma-easypayzarinpal-product">
    <form action="<?php print $cntlink; ?>" method="POST">
        <table>
	    <?php if($list['picture']) : ?>
            <tr>
                <td><img src="<?php print $list['picture']; ?>" /></td>
            </tr>
	    <?php endif; ?>
	    <?php if($list['cost']) : ?>			
	    <tr>
	      <td>
	        <span><?php print JText::_('COM_MA_EASYPAYZARINPAL_COST').JText::_('COM_MA_EASYPAYZARINPAL_RIAL'); ?>
	         <input type="text" id="cost" name="cost" readonly="readonly" size="<?php print strlen($list['cost'])-2; ?>" value="<?php print $list['cost']; ?>" /></span>
	      </td>
	    </tr>
	    <?php endif; ?>
	    <tr>
	        <td colspan="2"><input id="submit" type="submit" value="<?php print JText::_('COM_MA_EASYPAYZARINPAL_PAYMENT'); ?>" /></td>
	    </tr>
        </table>
    </form>
</div>