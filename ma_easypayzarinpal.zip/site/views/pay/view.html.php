<?php
defined( '_JEXEC' ) or die;

jimport( 'joomla.application.component.view');
class Ma_EasyPayZarinpalViewPay extends JView
{
	protected $form;

	public function display($tpl = null)
	{
		$this->form	= $this->get('Form');
		parent::display($tpl);
	}
}
?>