<?php
defined( '_JEXEC' ) or die;
class Ma_EasyPayZarinpalTableEasypayzarinpal extends	JTable
{
	public function __construct(&$db)
	{
		parent::__construct('#__ma_easypayzarinpal','id',$db);
	}
}
?>