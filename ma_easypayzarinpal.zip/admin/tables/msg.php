<?php
defined( '_JEXEC' ) or die;
class Ma_EasyPayZarinpalTableMsg extends	JTable
{
	public function __construct(&$db)
	{
		parent::__construct('#__ma_easypayzarinpal_bankmsg','id',$db);
	}
}
?>