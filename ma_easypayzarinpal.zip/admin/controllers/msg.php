<?php
defined( '_JEXEC' ) or die;

jimport('joomla.application.component.controllerform');
class   Ma_EasyPayZarinpalControllerMsg   extends JControllerForm
{	
	protected $view_list	=	'msglist';	
}
?>