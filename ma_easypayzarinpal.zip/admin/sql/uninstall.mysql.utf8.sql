DROP TABLE #__ma_easypayzarinpal;
DROP TABLE #__ma_easypayzarinpal_bankmsg;
