ALTER TABLE `#__ma_easypayzarinpal` CHANGE `phone` `phone` VARCHAR( 11 ) NOT NULL DEFAULT '0';
ALTER TABLE `#__ma_easypayzarinpal` CHANGE `mobile` `mobile` VARCHAR( 11 ) NOT NULL DEFAULT '0';
ALTER TABLE `#__ma_easypayzarinpal` CHANGE `mellicode` `mellicode` VARCHAR( 10 ) NOT NULL DEFAULT '0';