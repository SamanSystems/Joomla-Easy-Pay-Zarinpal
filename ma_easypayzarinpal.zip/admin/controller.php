<?php
defined( '_JEXEC' ) or die;

jimport('joomla.application.component.controller');
class Ma_EasyPayZarinpalController extends JController
{
    public function display($cachable = false, $urlparams = false)
    {
        JRequest::setVar('view', JRequest::getCmd('view', 'paylist'));
        parent::display($cachable, $urlparams);
    }
}
?>