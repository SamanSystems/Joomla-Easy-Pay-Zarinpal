<?php
defined( '_JEXEC' ) or die;

jimport( 'joomla.application.component.view');
class Ma_EasyPayZarinpalViewMsglist extends JView
{
    protected $items;
	protected $pagination;
	protected $state;

	public function display($tpl = null)
	{
        $this->items = $this->get('Items');
		$this->pagination = $this->get('Pagination');
		$this->state = $this->get('State');

        //add Toolbar
        $this->addToolbar();
        parent::display($tpl);
	}
    
    public function addToolbar()
    {
   		$doc	= JFactory::getDocument();
		$doc->addStyleSheet('../media/com_ma_easypayzarinpal/css/admin.stylesheet.css');
		JToolBarHelper::title(JText::_('COM_MA_EASYPAYZARINPAL_MSGLIST_TITLE'),'msglist.png');
		JToolBarHelper::addNew('msg.add');
		JToolBarHelper::editList('msg.edit');
		JToolBarHelper::deleteList('', 'msglist.delete');
    }
}
?>