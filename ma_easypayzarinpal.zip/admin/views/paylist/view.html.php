<?php
defined( '_JEXEC' ) or die;

jimport( 'joomla.application.component.view');
class Ma_EasyPayZarinpalViewPaylist extends JView
{
    protected $items;
	protected $pagination;
	protected $state;

	public function display($tpl = null)
	{
        $this->items = $this->get('Items');
		$this->pagination = $this->get('Pagination');
		$this->state = $this->get('State');

        //add Toolbar
        $this->addToolbar();
        parent::display($tpl);
	}
    
    public function addToolbar()
    {
   		$doc	= JFactory::getDocument();
		$doc->addStyleSheet('../media/com_ma_easypayzarinpal/css/admin.stylesheet.css');
		JToolBarHelper::title(JText::_('COM_MA_EASYPAYZARINPAL_PAYLIST_TITLE'),'paylist.png');
        JToolBarHelper::editList('pay.edit');
        JToolBarHelper::divider();
        JToolBarHelper::publishList('paylist.publish');
        JToolBarHelper::unpublishList('paylist.unpublish');
        JToolBarHelper::archiveList('paylist.archive');
		JToolBarHelper::divider();
		JToolBarHelper::deleteList('', 'paylist.delete');
		JToolBarHelper::trash('paylist.trash');
		JToolBarHelper::divider();
		JToolBarHelper::preferences('com_ma_easypayzarinpal');
    }
}
?>