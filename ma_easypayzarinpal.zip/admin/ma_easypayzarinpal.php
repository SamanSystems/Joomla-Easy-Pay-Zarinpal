<?php
defined( '_JEXEC' ) or die;

jimport('joomla.application.component.controller');
JLoader::register('Ma_EasyPayZarinpalHelper', dirname(__FILE__) . DS . 'helpers' . DS . 'ma_easypayzarinpal.php');
$controller = JController::getInstance('Ma_EasyPayZarinpal');
$controller->execute(JRequest::getCmd('task'));
$controller->redirect();
?>