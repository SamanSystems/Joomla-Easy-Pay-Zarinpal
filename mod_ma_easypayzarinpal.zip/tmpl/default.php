﻿<?php
// no direct access
defined('_JEXEC') or die;
$needle = 'index.php?option=com_ma_easypayzarinpal&view=pay';
$menu = JFactory::getApplication()->getMenu();
$item = $menu->getItems('link', $needle, true);
$cntlink = !empty($item) ? $needle .'&amp;Itemid=' . $item->id : $needle ;
?>
<style>
#ma-easypayzarinpal table{width:100%;padding:5px;}
#ma-easypayzarinpal table input#cost{text-align:left}
</style>
<div id="ma-easypayzarinpal">
    <form action="<?php print $cntlink; ?>" method="POST">
        <table>
            <tr>
                <td><label for="cost"><?php print JText::_('COM_MA_EASYPAYZARINPAL_PLEASE_ENTER_COST'); ?></label></td>
            </tr>
            <tr>
		<td><input id="cost" type="text" name="cost" value="20000" /></td>
	    </tr>
    	    <tr>
		<td colspan="2"><input type="submit" value="<?php print JText::_('COM_MA_EASYPAYZARINPAL_PAYMENT'); ?>" /></td>
	    </tr>
        </table>
    </form>
</div>